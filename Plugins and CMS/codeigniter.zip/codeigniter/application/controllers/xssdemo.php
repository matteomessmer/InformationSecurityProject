// application/controllers/xssdemo.php
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Xssdemo extends CI_Controller {

        public function index() {
            $data['xss'] =
$this->security->xss_clean($this->input->post('xss'));
            $this->load->view('xssdemo', $data);
        }
}
